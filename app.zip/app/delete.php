<?php
include './classes/databaseManupulation.php';
$db = new databaseManupulation();

$data = json_decode(file_get_contents("php://input"));

$TABLENAME = "tasks";
$CONDITION =  "task_id=$data->task_id";
$delete = $db->DELETE_ALL_FROM_DATABASE_WHERE($TABLENAME, $CONDITION);

echo 'true';

if(mysql_num_rows($delete)>0)
{
    echo 'true';
}
else
{
    echo 'Kubi';
}


