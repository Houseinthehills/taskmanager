<?php

session_start();
if (isset($_SESSION["email"])) 
    {
    $email2 = $_SESSION["email"];
    
}
include './classes/databaseManupulation.php';
$db = new databaseManupulation();

$TABLENAME = "tasks";
$CONDITION =  "email='$email2'";
$results = $db->SELECT_WHERE_FROM_DATABASE($TABLENAME, $CONDITION);

$array = array();

if (mysql_num_rows($results) > 0) {
    while ($row = mysql_fetch_assoc($results)) {
        $array[] = $row;
    }
} else {
    echo 'You have no task created';
}
echo $res = json_encode($array);
