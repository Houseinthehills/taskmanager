<?php
include './classes/databaseManupulation.php';
$db = new databaseManupulation();

$data = json_decode(file_get_contents("php://input"));
$name = mysql_real_escape_string($data->name);
$surname = mysql_real_escape_string($data->surname);
$email = mysql_real_escape_string($data->email);
$password = mysql_real_escape_string($data->password);

$TABLENAME =  "register";
$convertPassword = md5($password);
$VALUES = "'null','$name','$surname','$email','$convertPassword'";
$registerUser = $db->INSERT_INTO_DATABASE($TABLENAME, $VALUES);

if(mysql_affected_rows()>0)
{
    echo 'Registered';
}
else
{
    echo 'Error';
}