<!DOCTYPE html>
<html ng-app="MyApp">
    <head>
        <meta charset="UTF-8">
        <title>To-Do-List |  Application</title>
        <!--My CSS-->
        <link rel="stylesheet" href="css/assets/css/bootstrap.css">
        <link rel="stylesheet" href="css/assets/css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/assets/css/bootstrap.min.css">
        <link href="css/styles.css" rel="stylesheet">
        <!--My javascripts-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>  
        <script src="angular/js.js"></script>
        <script src="angular/angular.js"></script>
        <script src="angular/angular-route.js"></script>
        <script src="angular/route-mini.js"></script>
        <script src="angular/app.js"></script>

        <!--My controllers -->
        <script src="angular/controllers/registration.js"></script>
        <script src="angular/controllers/login.js"></script>
        <script src="angular/controllers/tasks.js"></script>
        <script src="angular/controllers/logout.js"></script>



    </head>
    <body>
        <div class="page" >
            <div class="cf" ng-view>
            </div>
        </div>
        <br /> <br />
      
    </body>
</html>
