<?php
 session_start();
   if(isset($_SESSION["email"]))
   { 
    $email2 = $_SESSION["email"];
     
   }
include './classes/databaseManupulation.php';
$db = new databaseManupulation();
$data  = json_decode(file_get_contents("php://input"));
$taskName = mysql_real_escape_string($data->taskname);
$dateStart = mysql_real_escape_string($data->startdate);
$dateEnd = mysql_real_escape_string($data->enddate);
$description = mysql_real_escape_string($data->taskdescription);
$TABLENAME ="tasks";
 $VALUES =  "'NULL','$taskName','$dateStart','$dateEnd','$description','$email2' " ;      
$inserttasks =  $db->INSERT_INTO_DATABASE($TABLENAME, $VALUES);

if(mysql_affected_rows() >0)
{
    echo 'Task added';
}
 else
{
    echo 'Try again please';          
}
