<?php
session_start();
include './classes/databaseManupulation.php';
$db = new databaseManupulation();

$data = json_decode(file_get_contents("php://input"));
$email = mysql_real_escape_string($data->email);
$passwordLogin = mysql_real_escape_string($data->passwordLogin);

$TABLENAME =  "register";
$convertPasswordLogin = md5($passwordLogin);

$CONDITION =  "email='$email' && password='$convertPasswordLogin'";
$loginSelect =  $db->SELECT_WHERE_FROM_DATABASE($TABLENAME, $CONDITION);
$trust =  0;

if(mysql_num_rows($loginSelect) > 0)
{
     echo $trust =  1;
     
     $row = mysql_fetch_assoc($loginSelect);
     $_SESSION["email"] =  $row["email"];
     $_SESSION["name"] =  $row["name"];
}
else
{
      echo $trust =  2; 
}

echo $results = json_encode($trust);
