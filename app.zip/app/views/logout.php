<div class="logout" ng-controller="LogoutController">
</div>