<div class="container">
           <div class="jumbotron">
        <h1>Welcome</h1>
        <p>This example is a quick exercise to illustrate how the default, static and fixed to top navbar work. It includes the responsive CSS and HTML, so it also adapts to your viewport and device.</p>
        <p>To see the difference between static and fixed top navbars, just scroll.</p>
       
      </div>
    <div class="container">
        <form class="form-signin" novalidate name="myform" ng-submit="success()">
        <h2 class="form-signin-heading">VOTE FOR CANDIDATE</h2>
         <label for="inputEmail" class="sr-only">Name</label>
        <input id="inputEmail" class="form-control" placeholder="Name" type="text" ng-model="user.name" ng-required="true"><br />
        <label for="inputEmail" class="sr-only">Surname</label>
        <input id="inputEmail" class="form-control" placeholder="Surname" type="text" ng-model="user.surname" ng-required="true"><br />
        <button class="btn btn-lg btn-primary btn-block" type="submit" ng-disabled="myform.$invalid">Vote now</button>        
        <p ng-show="message">{{ message }}</p>
        </form>
    </div>
    </div>