<ul class="nav nav-tabs">
  <li role="presentation" class="active"><a ng-href="#/login">Login</a></li>
  <li role="presentation"><a ng-href="#/register">Register</a></li>
</ul>