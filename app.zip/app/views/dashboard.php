<?php
session_start();
if (isset($_SESSION["email"])) {
        $_SESSION["email"];
        $_SESSION["name"];
}
?>
<div class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <!-- Logo -->
                <div class="logo">
                    <h1><a ng-href="#/dashboard" class="testMe">MANAGE YOUR TASKS | <span class="block-name"><?php echo $_SESSION["name"]; ?> </span></a></h1>
                </div>
            </div>
            <div class="col-md-5">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="input-group form">
                            <input type="text" class="form-control block-search" placeholder="Search..." ng-model="search">
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<div class="page-content" ng-controller="Dashboard">
    <div class="row">
        <div class="col-md-2">

            <div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="#/dashboard"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
                    <li><a href="#/dashboard"><i class="glyphicon glyphicon-calendar"></i> Calendar</a></li>

                    <li class="submenu">
                        <a ng-href="#/logout">
                            <i class="glyphicon glyphicon-road"></i> logout
                            <span class=" pull-right"></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-md-10">
            <div class="row">
                <div class="col-md-6">
                    <div class="content-box-large">
                        <div class="panel-heading">
                            <div class="panel-title">Add your list for today</div>

                            <div class="panel-options">
                                <a href="#/dashboard" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="panel-body">
                                <form class="form-horizontal" role="form" name="myform" ng-submit="taskload()">
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">TASK NAME</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control block-border-remove" id="inputEmail3" placeholder="Task name" ng-model="taskname" required="true">         
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">START DATE</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control block-border-remove"  id="datepicker"  placeholder="Start date" ng-model="startdate" required="true">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label" >END DATE</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control block-border-remove"  id="datepicker2"  placeholder="End date" ng-model="enddate" required="true">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Description</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control block-border-remove" placeholder="Textarea" rows="3" ng-model="taskdescription"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-offset-2 col-sm-10">
                                            <button type="submit" class="btn btn-primary block-large-button" ng-disabled="myform.$invalid">ADD TASK</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="content-box-header">
                                <div class="panel-title">YOUR LIST</div>

                                <div class="panel-options">
                                    <a href="#/dashboard" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
                                    <a href="#/dashboard" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
                                </div>
                            </div>
                            <div class="content-box-large box-with-header">
                                <ul class="list-group" ng-repeat="x in results| filter : search">
                                    <li  class="list-group-item"><span id="block-show">{{x.taskname}} |  {{x.dateStart}}</span><span class="glyphicon glyphicon-trash pull-right" aria-hidden="true" ng-click="deleteTask(x)"></span></li>
                                    <div class="alert alert-warning" id="block-hide" role="alert">{{x.description}}</div>
                                </ul> 
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="content-box-header">
                                <div class="panel-title">DESCRIPTION</div>

                                <div class="panel-options">
                                    <a href="#/dashboard" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
                                    <a href="#/dashboard" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
                                </div>
                            </div>
                            <div class="content-box-large box-with-header">
                                Pellentesque luctus quam quis consequat vulputate. Sed sit amet diam ipsum. Praesent in pellentesque diam, sit amet dignissim erat. Aliquam erat volutpat. Aenean laoreet metus leo, laoreet feugiat enim suscipit quis. Praesent mauris mauris, ornare vitae tincidunt sed, hendrerit eget augue. Nam nec vestibulum nisi, eu dignissim nulla.
                                <br /><br />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 panel-warning">
                    <div class="content-box-header panel-heading">
                        <div class="panel-title ">New vs Returning Visitors</div>

                        <div class="panel-options">
                            <a href="#/dashboard" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
                            <a href="#/dashboard" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
                        </div>
                    </div>
                    <div class="content-box-large box-with-header">
                        Pellentesque luctus quam quis consequat vulputate. Sed sit amet diam ipsum. Praesent in pellentesque diam, sit amet dignissim erat. Aliquam erat volutpat. Aenean laoreet metus leo, laoreet feugiat enim suscipit quis. Praesent mauris mauris, ornare vitae tincidunt sed, hendrerit eget augue. Nam nec vestibulum nisi, eu dignissim nulla.
                        <br /><br />
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer>
    <div class="container">
        <div class="copy text-center">
            Copyright 2017 <a href='#'>Website</a>
        </div>
    </div>
</footer>



