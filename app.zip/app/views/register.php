<div class="page-content container block-login" ng-controller="RegistrationController">
    <form class="form-signin" novalidate name="myform" ng-submit="register()">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-wrapper">
                    <div class="box">
                        <div class="content-wrap">
                            <h6>Sign Up</h6>
                            <div class="social">

                                <div class="division">
                                    <div class="alert alert-info" role="alert">Simple way to manage your daily tasks, Register and see for yourself.</div>
                                </div>
                            </div>
                            <label for="inputEmail" class="sr-only">Name</label>
                            <input id="inputEmail" class="form-control" placeholder="Name" type="text" ng-model="name" ng-required="true">
                            <br />
                            <label for="inputEmail" class="sr-only">Surname</label>
                            <input id="inputEmail" class="form-control" placeholder="Surname" type="text" ng-model="surname" ng-required="true">
                            <br />
                            <label for="inputEmail" class="sr-only">Email address</label>
                            <input id="inputEmail" class="form-control" placeholder="Email address" type="email" ng-model="email" ng-required="true">
<!--<p class="error-color" ng-show="myform.email.$invalid && myform.email.$touched">Please</p>-->
                            <br />
                            <label for="inputPassword" class="sr-only">Password</label>
                            <input id="inputPassword" class="form-control" placeholder="Password"  type="password" ng-model="password" ng-required="true">
                            <br />
                            <label for="inputPassword" class="sr-only">Verify password</label>
                            <input id="inputPassword" class="form-control" placeholder="Verify password"  type="password" ng-model="password2" ng-required="true">

                            <div class="action">
                                <button class="btn btn-lg btn-primary btn-block" type="submit" ng-disabled="myform.$invalid">Sign up</button>     
                            </div>                
                        </div>
                    </div>
                    <div class="already">
                        <p>Don't have an account yet?</p>
                        <a ng-href="#/login">Sign in</a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>