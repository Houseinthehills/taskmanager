<div class="page-content container block-login" ng-controller="LoginController">
    <form class="form-signin" novalidate name="myform" ng-submit="login()">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-wrapper">
                    <div class="box">
                        <div class="content-wrap">
                            <h6>Sign In</h6>
                            <div class="social">
<!--                                <a class="face_login" href="#">
                                    <span class="face_icon">
                                        <img src="images/facebook.png" alt="fb">
                                    </span>
                                    <span class="text">Sign in with Facebook</span>
                                </a>-->
                                 <div class="division">
                                    <div class="alert alert-info" role="alert">Simple way to manage your daily tasks, Register and see for yourself.</div>
                                </div>
                            </div>
                            <input id="inputEmail" class="form-control" placeholder="Email address" type="email" ng-model="email" ng-required="true">
                            <br />
                            <input id="inputPassword" class="form-control" placeholder="Password"  type="password" ng-model="passwordLogin" ng-required="true">
                            <div class="action">
                                <button class="btn btn-lg btn-primary btn-block " type="submit" ng-disabled="myform.$invalid">Sign in</button>     
                            </div>                
                        </div>
                    </div>
                    <div class="already">
                        <p>Don't have an account yet?</p>
                        <a ng-href="#/register">Sign Up</a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
