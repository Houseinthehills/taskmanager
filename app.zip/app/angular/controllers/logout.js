myApp.controller('LogoutController', function ($scope, $http, $location)
{
    $http.post('logout.php').success(function (data)
    {
        var history_api = typeof history.pushState !== 'undefined';
        if (history_api)
        {
           // history.pushState(null, '', '#');
            $location.path("/");
            
            
        }
    });
});