myApp.controller('Dashboard', function ($scope, $http, $location)
{

    $("#datepicker").datepicker();
    $("#datepicker2").datepicker();

    $http.post('results.php').success(function (data)
    {
        $scope.results = data;

    });


    $scope.taskload = function ()
    {
        $http.post('task.php',
                {
                    'taskname': $scope.taskname,
                    'startdate': $scope.startdate,
                    'enddate': $scope.enddate,
                    'taskdescription': $scope.taskdescription

                }).success(function (data)
        {
            alert("Task added");
            location.reload();

        });
    };

    $scope.deleteTask = function (info)
    {
        var txt;
        var r = confirm("Are you deleting ?");
        if (r == true) {
            txt = "You pressed OK!";
            location.reload();
            $http.post('delete.php', {"task_id": info.task_id}).success(function (data)
            {
                if (data == true)
                {
                   // location.reload();
                   $location.path('/dashboard');
                }
            });
        } else {
            txt = "You pressed Cancel!";
        }
    };




});

