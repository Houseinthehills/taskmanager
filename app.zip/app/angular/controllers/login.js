myApp.controller('LoginController', function($scope, $http, $location)
{
       $scope.login =  function()
       {
              $http.post('login.php',
              {
                  'email': $scope.email,
                  'passwordLogin' : $scope.passwordLogin
                  
              }).success(function(data)
              {
                  if(data == 11)
                  {
                      alert("Welcome");
                      $location.path('/dashboard');
                  }
                  else
                  {
                      alert("ERROR:  PLEASE CHECK YOUR LOGIN DETAILS");
                  }
                   
              }); 
      };
});
