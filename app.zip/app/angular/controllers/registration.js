myApp.controller("RegistrationController", function($scope, $http)
{
         $scope.register = function()
         {
             if($scope.password === $scope.password2)
             {
                  $http.post('register.php',
                    {
                        'name' : $scope.name,
                        'surname': $scope.surname,
                        'email': $scope.email,
                        'password': $scope.password
                    }).success(function(data,headers,status,config)
                    {
                            alert(data);
                    });
             }
             else
             {
                 alert("password missmatch");
             }
             
             
         };
});