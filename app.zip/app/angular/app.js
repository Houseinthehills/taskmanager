var myApp = angular.module('MyApp', ['ngRoute']);
myApp.config(['$routeProvider', function($routeProvider)
{
    $routeProvider.
        when('/',
        {
           templateUrl:'views/login.php',
           controller:'LoginController'
        }).
         when('/register',
        {
           
           templateUrl:'views/register.php',
           controller:'RegistrationController'
        }).
        when('/success',
        {
           templateUrl:'views/success.php',
           controller:'SuccessController'
        }).
         when('/dashboard',
       {
           templateUrl:'views/dashboard.php',
           controllers: 'Dashboard'
       }).when('/logout',
       {
              templateUrl:'views/logout.php',
              controller: 'LogoutController'
       }) .otherwise
       ({
            redirectTo:'/'
        });
}]);
