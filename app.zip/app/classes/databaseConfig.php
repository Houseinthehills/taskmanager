<?php
/**
 * databaseConfig connects to database 
 *
 * @author Derrick Mphurpi
 * 
 */
//include 'config.php';
class databaseConfig 
{
    /*
     * This constructor connects to database 
     */
    function __construct() 
    {
        /**
         *This accepts the credentials to conncet to database 
         */
       $select = mysql_connect(SERVER_NAME,USER_NAME,PASSWORD) or die("Error : " .mysql_error());
       /*
        * This method selects database
        */
       $res = mysql_select_db(DATABASE_NAME) or die("error : ".mysql_error());
    }
}

?>
