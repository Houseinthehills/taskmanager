<?php
/*
 * Author Derrick Siho Mphurpi 
 * Date 16 April 2014
 * This php file will define all the constants that you need 
 * to connect to database 
 */

/*
 * This constant defines the server name 
 * SERVER_NAME is a variable that contains the server
 * localhost is the server name 
 */
define("SERVER_NAME","localhost");
/*
 * This USER_NAME constant defines the username of the server
 * root is the username
 */
define("USER_NAME","root");
/*
 * This PASSWORD constant defines the password of the server
 * 
 */
define("PASSWORD","root");
 /*
  * This DATABASE_NAME constant defines the database name 
  * DATABASE_NAME is the database 
  */   
define("DATABASE_NAME","toDoList");
?>
