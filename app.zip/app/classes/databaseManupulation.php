<?php

/**
 * This class contains all the sql statements that will help you
 * manupulate the database 
 *
 * @author Derrick Mphurpi
 * 
 */
include 'configurationClass.php';
include 'databaseConfig.php';

class databaseManupulation extends databaseConfig {

    function __construct() {
        parent::__construct();
    }

    /*
     * This function will select * from the database 
     */

    function SELECT_ALL_FROM_DATABASE($TABLENAME) {
        $selectall = "SELECT * FROM " . $TABLENAME;
        $results = mysql_query($selectall) or die("Error : " . mysql_error());
        return $results;
    }

    /*
     * This function will select all from database where condition is equals to true
     */

    function SELECT_WHERE_FROM_DATABASE($TABLENAME, $CONDITION) {
        $selectWhere = "SELECT * FROM " . $TABLENAME . " WHERE " . $CONDITION;
        $results = mysql_query($selectWhere) or die("Error : " . mysql_error());
        return $results;
    }

    /*
     * This function will delete all the records from the database 
     */

    function DELETE_ALL_FROM_DATABASE($TABLENAME) {
        $deleteAll = "DELETE FROM " . $TABLENAME;
        $resuts = mysql_query($deleteAll) or die("error : " . mysql_error());
        return $resuts;
    }

    /*
     * This function will delete * from where condition is true
     */

    function DELETE_ALL_FROM_DATABASE_WHERE($TABLENAME, $CONDITION) {
        $deleteAllfromDatabaseWhere = "DELETE FROM " . $TABLENAME . " WHERE " . $CONDITION;
        $results = mysql_query($deleteAllfromDatabaseWhere) or die("Error : " . mysql_error());
        return $results;
    }

    /*
     * This function will Update database where the condition is true
     */

    function UPDATE_DATABASE_WHERE($TABLENAME, $CONDITION, $SET) {
        $updateDatabaseWhere = "UPDATE " . $TABLENAME . " SET " . $SET . " WHERE " . $CONDITION;
        $results = mysql_query($updateDatabaseWhere)or die("Error : " . mysql_error());
        return $results;
    }

    /*
     * This function will Update database with all the values set
     */

    function UPDATE_DATABASE($TABLENAME, $SET) {
        $updateDatase = "UPDATE " . $TABLENAME . " SET " . $SET;
        $results = mysql_query($updateDatase)or die("Error : " . mysql_error());
        return $results;
    }

    /*
     * This function will insert data into database the fields will be inserted
     * 
     */

    function INSERT_INTO_DATABASE($TABLENAME, $VALUES) {
        $insertIntoDatabase = " INSERT INTO " . $TABLENAME . " VALUES (" . $VALUES . ")";
        $results = mysql_query($insertIntoDatabase) or die("Error : " . mysql_error());
        return $results;
    }

    function SELECT_LAST_RECORD($TABLE, $ID) {
        $selectingLastRow = "SELECT * FROM " . $TABLE . " ORDER BY " . $ID . " DESC LIMIT 1";
        $results = mysql_query($selectingLastRow) or die("Error" . mysql_error());
        return $results;
    }

    function SELECT_ALL_BY_ORDER($TABLE_NAME, $ID) {

        $selectAllFrom = "SELECT * FROM " . $TABLE_NAME . " ORDER BY " . $ID . " DESC LIMIT 12000000";
        $results = mysql_query($selectAllFrom) or die("Error :" . mysql_error());

        return $results;
    }

    function SELECT_WHERE_BY_ORDER($TABLE_NAME, $ID, $CONDITION) {

        $selectAllFrom = "SELECT * FROM " . $TABLE_NAME . " WHERE " . $CONDITION . " ORDER BY " . $ID . " DESC LIMIT 12000000";
        $results = mysql_query($selectAllFrom) or die("Error :" . mysql_error());

        return $results;
    }
    

}

?>
