<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of loginClass
 *
 * @author NIce
 */
class loginClass {
    //put your code here
    private $username;
    private $password;
    
    function __construct($username,$password) {
        
        $this->username = $username;
        $this->password = $password;
    }
    function VALIDATE_USERNAME()
    {
        if($this->username =="" || $this->username == NULL)
        {
            return "USERNAME NAME MUST NOT BE EMPTY";
        }
    }
    function VALIDATE_PASSWORD()
    {
        if($this->password=="" || $this->password== NULL)
        {
            return"PASSWORD MUST NOT BE EMPTY";
        }      
    }
}

?>
