<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of validateBooks
 *
 * @author NIce
 */
class validateBooks {
    
    private $bookName;
    private $authorName;
    private $price;
    private $department;
    private $yearLevel;
    private $uploadImage;
    private $isbn;
            
    function __construct($bookName,$authorName,$price,$department,$isbn,$yearLevel,$uploadImage)
    {
        $this-> bookName = $bookName;
        $this->authorName = $authorName;
        $this->price = $price;
        $this->department = $department;
        $this->yearLevel = $yearLevel;
        $this->uploadImage = $uploadImage;
        $this->isbn= $isbn;
    }
    function BOOKNAME_EMPTY()
    {
        if($this->bookName == "" || $this->bookName == NULL)
        {
            return "BOOK NAME MUST NOT BE EMPTY";
        }
    }
    function AUTHORNAME_EMPTY()
    {
         if($this->authorName=="" || $this->authorName==NULL)
         {
             return "AUTHOR NAME MUST NOT BE EMPTY";
         }
    }
    function BOOKPRICE_EMPTY()
    {
        if($this->price=="" || $this->price==NULL)
        {
            return "BOOK PRICE MUST NOT BE EMPTY";
        }
    }
    function DEPARTMENT_NONE()
    {
        if($this->department == "None")
        {
            return "CHOOSE DEPARTMET";
        }
    }
       function ISBN_NONE()
    {
        if($this->isbn == "" || $this->isbn=="Null")
        {
            return "ISBN MUST NOT BE EMPTY";
        }
    }
    function YEARLEVEL_NONE()
    {
        if($this->yearLevel=="None")
        {
            return"CHOOSE YEAR LEVEL";
        }
    }
    function UPLOAD_EMPTY()
    {
        if($this->uploadImage == "" || $this->uploadImage ==NULL)
        {
            return "CHOOSE BOOK IMAGE";
        }
    }
    function VALIDATE_PRICE_NUMERIC()
    {
       if(!is_numeric($this->price))
       {
           return"PRICE MUST BE NUMERIC";
       }
    }
    function VALIDATE_AUTHOR_NUMERIC()
    {
        if(is_numeric($this->authorName))
       {
           return"AUTHOR NAME  MUST NOT BE NUMERIC";
       }
    }
}

?>
