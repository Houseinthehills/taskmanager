<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of register
 *
 * @author NIce
 */
class register {
    //put your code here
    private $names;
    private $emailAddres;
    private $contactNumbers;
    private $password;
    private $image;
    private $gender;
    private $age;
    private $course;
    
    function __construct($names,$gender,$age,$course,$emailAddres,$contactNumbers,$password,$image) 
    {
        $this->names = $names;
        $this->emailAddres  = $emailAddres;
        $this->contactNumbers = $contactNumbers;
        $this->password = $password;
        $this->image = $image;
        $this->gender = $gender;
        $this->age =$age;
        $this->course= $course;
                
    }
    function NAMES()
    {
            if($this->names == "" || $this->names == NULL)
            {
                return "NAMES MUST NOT BE EMPTY";
            }
    }
    function EMAILADDRESS()
    {
        if($this->emailAddres == "" || $this->emailAddres==NULL)
        {
            return "EMAIL MUST NOT BE EMPTY";
        }
    }
    function CONTACTNUMBERS()
    {
        if($this->contactNumbers=="" ||$this->contactNumbers==NULL)
        {
            return"CONTACT NUMBER MUST NOT BE EMPTY";
        }
    }
    function PASSWORD()
    {
        if($this->password =="" || $this->password==NULL)
        {
            return "PASSWORD MUST NOT BE EMPTY";
        }
            
    }
    function NAMES_NUMERIC()
    {
        if(is_numeric($this->names)==TRUE)
        {
            return"NAME MUST NOT BE NUMERIC";
        }
    }
    function  VALIDATING_EMAIL()
    {
        if(!filter_var($this->emailAddres,FILTER_VALIDATE_EMAIL))
        {
            return"INVALID EMAIL ADDRESS";
        }
    }
    function  VALIDATE_NUMBER_LENGTH()
    {
        if(strlen($this->contactNumbers) <10)
        {
            return "CONTACT NUMBER MUST BE 10 DIGITS";
        }
    }
    function VALIDATE_IMAGE_EMPTY()
    {
    
           if($this->image == "" || $this->image==NULL)
           {
               return "PLEASE UPLOAD IMAGE";
           }
    }
     function VALIDATE_GENDER_EMPTY()
    {
    
           if($this->gender == "none" )
           {
               return "GENDER MUST NOT BE NONE";
           }
    }
     function VALIDATE_AGE_EMPTY()
    {
    
           if($this->age == "" || $this->age==NULL)
           {
               return "AGE MUST BE ENTERED";
           }
    }
      function VALIDATE_COURSE_EMPTY()
    {
    
           if($this->course == "" || $this->course==NULL)
           {
               return "COURSE MUST BE ENTERED";
           }
    }
}

?>
